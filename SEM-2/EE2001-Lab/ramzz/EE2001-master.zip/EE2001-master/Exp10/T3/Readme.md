T1 - stands for Task 1 

Compiling :

iverilog testbench.v exp.v modules.v -o exp && vvp exp
