Clone this Directory
Run "g++ main.cpp circuit.cpp gates.cpp -o lsim && ./lsim" to show the output.
You can use generate.cpp to generate input values for truth table.
