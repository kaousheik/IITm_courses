Components Link : https://docs.google.com/spreadsheets/d/1H52fWCljC8QT4KlutFlhh5L_gqXCoZuKrvKGmKegJ8Y/edit?usp=sharing

Datasheets in Exp100
